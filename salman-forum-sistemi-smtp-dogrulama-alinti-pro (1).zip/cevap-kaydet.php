<?php
require_once __DIR__.'/app/core.php'; require_install();
if($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('');
if(!current_user()) redirect('giris.php');
csrf_check();
$u=current_user(); $tid=(int)($_POST['topic_id']??0); $content=trim((string)($_POST['content']??''));
function sfs_reply_error($msg){ http_response_code(400); $back=$_SERVER['HTTP_REFERER']??base_url(''); echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>İşlem yapılamadı</title><link rel="stylesheet" href="'.e(asset('assets/css/sfs.css')).'"></head><body><main class="wrap page"><div class="panel"><div class="panel-title">Cevap Kaydedilemedi</div><div class="panel-body"><div class="notice">'.e($msg).'</div><br><a class="btn" href="'.e($back).'">Geri Dön</a></div></div></main></body></html>'; exit; }
if($tid<=0) sfs_reply_error('Konu bilgisi alınamadı.');
if($content==='' || $content==='<br>' || $content==='<p><br></p>') sfs_reply_error('Cevap içeriği boş olamaz.');
$q=db()->prepare('SELECT id, slug, title, is_locked FROM sfs_topics WHERE id=? LIMIT 1'); $q->execute([$tid]); $topic=$q->fetch();
if(!$topic) sfs_reply_error('Konu bulunamadı.');
if((int)$topic['is_locked']===1 && !is_admin()) sfs_reply_error('Bu konu cevaplara kapalı.');
if(!empty($u['banned']) || ($u['role']??'')==='banned') sfs_reply_error('Hesabınız yasaklı olduğu için cevap yazamazsınız.');
$content=preg_replace('#<script\b[^>]*>(.*?)</script>#is','',$content); $content=preg_replace('/\son\w+\s*=\s*("|\').*?\1/iu','',$content); $content=preg_replace('/javascript\s*:/iu','',$content);
[$ok,$why]=sfs_reply_quality_check($content,$topic['title']??''); if(!$ok) sfs_reply_error($why);
try{ db()->beginTransaction(); $st=db()->prepare('INSERT INTO sfs_replies(topic_id,user_id,content,status,created_at) VALUES(?,?,?,?,NOW())'); $st->execute([$tid,(int)$u['id'],$content,'published']); db()->prepare('UPDATE sfs_topics SET replies=replies+1,last_reply_at=NOW() WHERE id=?')->execute([$tid]); db()->commit(); } catch(Throwable $e){ if(db()->inTransaction()) db()->rollBack(); sfs_reply_error('Veritabanı cevabı kaydedemedi: '.$e->getMessage()); }
redirect($topic['slug'].'#cevaplar');
