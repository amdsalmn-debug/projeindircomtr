<?php
$online=[]; $bots=[]; $new=[];
try{
  db()->exec("DELETE FROM sfs_online WHERE last_seen < DATE_SUB(NOW(), INTERVAL 60 MINUTE)");
  $online=db()->query("SELECT username,is_bot,bot_name,last_seen FROM sfs_online ORDER BY last_seen DESC LIMIT 18")->fetchAll();
  $bots=db()->query("SELECT bot_name, MAX(last_seen) last_seen FROM sfs_online WHERE is_bot=1 GROUP BY bot_name ORDER BY last_seen DESC LIMIT 10")->fetchAll();
  $new=db()->query("SELECT username,created_at FROM sfs_users ORDER BY id DESC LIMIT 8")->fetchAll();
}catch(Throwable $e){}
?>
</main>
<footer class="footer"><div class="wrap footgrid">
<section><h3><?=e(setting('site_title',SFS_NAME))?></h3><p><?=e(setting('footer_text','Modern, hızlı, SEO uyumlu ve lisanslı forum sistemi.'))?></p></section>
<section><h3>Online Kullanıcılar</h3><p><?php foreach($online as $o): ?><span class="pill <?=$o['is_bot']?'bot':''?>"><?=e($o['is_bot']?$o['bot_name']:$o['username'])?></span><?php endforeach; if(!$online) echo 'Henüz aktif kayıt yok.'; ?></p></section>
<section><h3>Gelen Botlar</h3><p><?php foreach($bots as $b): ?><span class="pill bot"><?=e($b['bot_name'])?></span><?php endforeach; if(!$bots) echo 'Bot görülmedi.'; ?></p></section>
<section><h3>Yeni Kullanıcılar</h3><p><?php foreach($new as $n): ?><span class="pill"><?=e($n['username'])?></span><?php endforeach; ?></p></section>
</div><div class="wrap footbottom"><span>© <?=date('Y')?> <?=e(setting('site_title',SFS_NAME))?></span><span><?=maker_link()?></span></div></footer>
</body></html>
