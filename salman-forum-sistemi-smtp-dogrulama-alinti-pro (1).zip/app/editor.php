<?php $name=$name ?? 'content'; $value=$value ?? ''; $id='ed_'.md5($name.rand()); ?>
<input type="hidden" name="<?=e($name)?>" id="<?=e($id)?>" value="<?=e($value)?>">
<div class="editor sfs-pro-editor" data-target="#<?=e($id)?>">
 <div class="editor-tabs"><button type="button" data-visual-tab class="active">Görsel</button><button type="button" data-html>HTML</button></div>
 <div class="editor-toolbar">
  <select data-format title="Biçim"><option value="p">Paragraf</option><option value="h1">Başlık 1</option><option value="h2">Başlık 2</option><option value="h3">Başlık 3</option><option value="blockquote">Alıntı</option><option value="pre">Kod Bloğu</option></select>
  <button type="button" data-cmd="bold"><b>B</b></button><button type="button" data-cmd="italic"><i>I</i></button><button type="button" data-cmd="underline"><u>U</u></button><button type="button" data-cmd="strikeThrough"><s>S</s></button>
  <button type="button" data-cmd="justifyLeft">Sol</button><button type="button" data-cmd="justifyCenter">Orta</button><button type="button" data-cmd="justifyRight">Sağ</button><button type="button" data-cmd="justifyFull">Yasla</button>
  <button type="button" data-cmd="insertUnorderedList">• Liste</button><button type="button" data-cmd="insertOrderedList">1. Liste</button>
  <button type="button" data-link>Link</button><button type="button" data-image>Görsel URL</button><button type="button" data-video>Video/Sosyal</button><button type="button" data-table>Tablo</button><button type="button" data-quote>Alıntı Kutusu</button><button type="button" data-code>Kod</button><button type="button" data-hr>Çizgi</button><button type="button" data-emoji>Emoji</button>
  <label class="colorpick">Yazı <input type="color" data-colorcmd="foreColor" value="#173c78"></label><label class="colorpick">Zemin <input type="color" data-colorcmd="hiliteColor" value="#fff2c7"></label>
  <button type="button" data-clear>Temizle</button><button type="button" data-full>Tam Ekran</button>
 </div>
 <div class="editor-area content" contenteditable="true"><?= $value ?></div>
 <textarea class="editor-html"></textarea>
 <div class="editor-help">Görseli kopyala-yapıştır veya sürükle-bırak yapabilirsin. YouTube, TikTok, Instagram, Facebook ve X bağlantılarını Video/Sosyal butonuyla ekleyebilirsin.</div>
</div>
