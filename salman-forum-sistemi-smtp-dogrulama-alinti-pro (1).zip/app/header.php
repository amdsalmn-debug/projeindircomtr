<?php require_once __DIR__.'/core.php'; require_install(); track_online(); $u=current_user(); $title=$page_title ?? setting('site_title',SFS_NAME); $desc=$page_desc ?? setting('seo_desc','Salman Forum Sistemi - hızlı, SEO uyumlu forum yazılımı.'); ?>
<!doctype html><html lang="tr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?=e($title)?></title><meta name="description" content="<?=e($desc)?>"><meta name="robots" content="<?=e(setting('robots_meta','index,follow'))?>">
<link rel="canonical" href="<?=e(((!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost').($_SERVER['REQUEST_URI']??'/'))?>">
<meta property="og:title" content="<?=e($title)?>"><meta property="og:description" content="<?=e($desc)?>"><meta property="og:type" content="website">
<link rel="stylesheet" href="<?=asset('assets/css/sfs.css')?>">
<script>window.SFS_BASE = <?=json_encode(rtrim(base_url(''),'/'))?>;</script>
<script defer src="<?=asset('assets/js/editor.js')?>"></script><script defer src="<?=asset('assets/js/app.js')?>"></script>
<?=setting('custom_head','')?>
</head><body>
<header class="topbar"><div class="wrap topgrid"><a class="brand" href="<?=base_url('')?>"><span class="brandmark">SF</span><span><b><?=e(setting('site_title',SFS_NAME))?></b><small><?=e(setting('site_slogan','Türkiye’nin profesyonel forum sistemi'))?></small></span></a>
<form class="search" action="<?=base_url('arama.php')?>"><input name="q" placeholder="Forumda ara..."><button>Ara</button></form>
<nav class="usernav"><?php if($u): ?><a href="<?=base_url('panel.php')?>">👤 <?=e($u['username'])?></a><a href="<?=base_url('cikis.php')?>">Çıkış</a><?php else: ?><a href="<?=base_url('giris.php')?>">Giriş</a><a class="btn-gold" href="<?=base_url('kayit.php')?>">Üye Ol</a><?php endif; ?></nav></div></header>
<nav class="navline"><div class="wrap"><a href="<?=base_url('')?>">Forum</a><a href="<?=base_url('son-konular.php')?>">Son Konular</a><a href="<?=base_url('yeni-konu.php')?>">Yeni Konu</a><?php if(is_admin()): ?><a href="<?=base_url('admin/')?>">Admin Panel</a><?php endif; ?></div></nav>
<main class="wrap page">
