<form id="cevap-formu" method="post" action="<?=base_url('cevap-kaydet.php')?>" class="form topic-submit-form reply-submit-form">
<input type="hidden" name="csrf" value="<?=e(csrf())?>">
<input type="hidden" name="topic_id" value="<?=e($t['id'])?>">
<label>Cevap Yaz</label>
<?php $name='content'; include __DIR__.'/editor.php'; ?>
<div class="countdown"></div>
<div class="notice" style="margin-top:10px">Linkleri görebilmek için konuya mantıklı bir cevap yazman gerekir. <b>asd, test, qwe</b> gibi rastgele cevaplar kabul edilmez.</div>
<div class="actions" style="margin-top:12px">
  <button class="btn" type="submit">Cevabı Gönder</button>
  <span class="muted">Gönder tuşundan sonra spam koruması için 10 saniye geri sayım başlar.</span>
</div>
</form>
