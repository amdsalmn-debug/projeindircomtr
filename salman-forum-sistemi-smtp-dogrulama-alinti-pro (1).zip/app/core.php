<?php
if (session_status() === PHP_SESSION_NONE) session_start();

define('SFS_NAME','Salman Forum Sistemi');
define('SFS_ROOT', realpath(__DIR__.'/..'));

function sfs_request_path(){
    $script = str_replace('\\','/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    $base = rtrim($script, '/');
    if (preg_match('~/admin$~',$base)) $base = rtrim(dirname($base),'/');
    if (preg_match('~/install$~',$base)) $base = rtrim(dirname($base),'/');
    return $base === '/' ? '' : $base;
}
function base_url($path=''){
    $base = sfs_request_path();
    return $base . ($path === '' ? '/' : '/' . ltrim($path,'/'));
}
function asset($path){ return base_url($path).'?v=202605-pro-final'; }
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function redirect($path){ header('Location: '.base_url($path)); exit; }
function installed(){ return file_exists(SFS_ROOT.'/app/config.php') && file_exists(SFS_ROOT.'/install.lock'); }
function require_install(){ if(!installed() && !preg_match('~/install~', $_SERVER['SCRIPT_NAME'] ?? '')) redirect('install/'); }
function cfg(){ static $c=null; if($c===null){ $c = file_exists(SFS_ROOT.'/app/config.php') ? require SFS_ROOT.'/app/config.php' : []; } return $c; }
function db(){ static $pdo=null; if($pdo) return $pdo; $c=cfg(); if(!$c) die('Kurulum gerekli.'); $dsn='mysql:host='.$c['db_host'].';dbname='.$c['db_name'].';charset=utf8mb4'; $pdo=new PDO($dsn,$c['db_user'],$c['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); return $pdo; }
function setting($key,$default=''){ try{ $q=db()->prepare('SELECT value FROM sfs_settings WHERE name=? LIMIT 1'); $q->execute([$key]); $v=$q->fetchColumn(); return $v!==false ? $v : $default; }catch(Throwable $e){ return $default; }}
function save_setting($key,$val){ $q=db()->prepare('INSERT INTO sfs_settings(name,value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)'); return $q->execute([$key,$val]); }
function slugify($text){
    $map=['ş'=>'s','Ş'=>'s','ı'=>'i','İ'=>'i','ğ'=>'g','Ğ'=>'g','ü'=>'u','Ü'=>'u','ö'=>'o','Ö'=>'o','ç'=>'c','Ç'=>'c'];
    $text=strtr($text,$map); $text=strtolower($text); $text=preg_replace('~[^a-z0-9]+~','-',$text); $text=trim($text,'-'); return $text ?: 'konu';
}
function unique_slug($title,$id=0){ $base=slugify($title); $slug=$base; $i=2; while(true){ $q=db()->prepare('SELECT id FROM sfs_topics WHERE slug=? AND id<>? LIMIT 1'); $q->execute([$slug,$id]); if(!$q->fetch()) return $slug; $slug=$base.'-'.$i++; }}
function csrf(){
    if(empty($_SESSION['csrf']) || !is_string($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_check(){
    $posted = (string)($_POST['csrf'] ?? $_POST['_csrf'] ?? '');
    $session = (string)($_SESSION['csrf'] ?? '');
    if($posted === '' || $session === '' || !hash_equals($session, $posted)){
        http_response_code(419);
        echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Güvenlik oturumu yenilendi</title><style>body{font-family:Arial;background:#eef3fb;margin:0;display:grid;place-items:center;min-height:100vh}.box{max-width:560px;background:white;border:1px solid #d6e0ef;border-radius:16px;padding:28px;box-shadow:0 20px 60px rgba(15,35,70,.12)}.btn{display:inline-block;background:#183b66;color:white;padding:12px 18px;border-radius:10px;text-decoration:none;font-weight:700}</style></head><body><div class="box"><h2>Oturum güvenliği yenilendi</h2><p>Sayfa uzun süre açık kaldığı, geri tuşu kullanıldığı veya form eski güvenlik anahtarıyla gönderildiği için işlem durduruldu.</p><p>Lütfen konu sayfasına geri dönüp sayfayı yenileyerek cevabı tekrar gönder.</p><a class="btn" href="javascript:history.back()">Geri Dön</a></div></body></html>';
        exit;
    }
}

function current_user(){ if(empty($_SESSION['uid'])) return null; static $u=null; if($u===null){ $q=db()->prepare('SELECT * FROM sfs_users WHERE id=?'); $q->execute([$_SESSION['uid']]); $u=$q->fetch(); } return $u; }
function is_admin(){ $u=current_user(); return $u && in_array($u['role'], ['super_admin','admin','moderator']); }
function require_admin(){ require_install(); if(!is_admin()) redirect('giris.php'); }
function login_user($id){ $_SESSION['uid']=$id; }
function logout_user(){ unset($_SESSION['uid']); }
function detect_bot(){ $ua=strtolower($_SERVER['HTTP_USER_AGENT']??''); $bots=['googlebot'=>'Googlebot','bingbot'=>'Bingbot','yandex'=>'YandexBot','duckduckbot'=>'DuckDuckBot','facebookexternalhit'=>'Facebook Bot','twitterbot'=>'X/Twitter Bot','tiktok'=>'TikTok Bot','ahrefs'=>'Ahrefs Bot','semrush'=>'Semrush Bot']; foreach($bots as $k=>$v){ if(strpos($ua,$k)!==false) return $v; } return ''; }
function track_online(){ if(!installed()) return; try{ $bot=detect_bot(); $u=current_user(); $q=db()->prepare('REPLACE INTO sfs_online(session_id,user_id,username,ip,user_agent,is_bot,bot_name,last_seen) VALUES(?,?,?,?,?,?,?,NOW())'); $q->execute([session_id(),$u['id']??null,$u['username']??'Misafir',$_SERVER['REMOTE_ADDR']??'',substr($_SERVER['HTTP_USER_AGENT']??'',0,250),$bot?1:0,$bot]); }catch(Throwable $e){} }
function can_view_topic_links($topic_id=0, $topic_owner_id=0){
    $u = current_user();
    if(!$u) return false;
    if(in_array($u['role'], ['super_admin','admin','moderator'])) return true;
    if($topic_owner_id && (int)$u['id'] === (int)$topic_owner_id) return true;
    if(!$topic_id) return true;
    try{
        $q = db()->prepare('SELECT id FROM sfs_replies WHERE topic_id=? AND user_id=? AND status=\'published\' LIMIT 1');
        $q->execute([(int)$topic_id, (int)$u['id']]);
        return (bool)$q->fetchColumn();
    }catch(Throwable $e){
        return false;
    }
}
function locked_link_message(){
    if(!current_user()){
        return '<span class="locked-link locked-link-reply"><b>🔒 Link gizli</b><small>Bu konudaki linkleri görebilmek için önce üye girişi yapıp konuya cevap yazmanız gerekiyor.</small></span>';
    }
    return '<span class="locked-link locked-link-reply"><b>🔒 Link gizli</b><small>Bu konudaki linkleri görebilmek için konuya cevap yazmanız gerekiyor. Cevabınızdan sonra linkler otomatik görünür.</small></span>';
}
function secure_content($html, $topic_id=0, $topic_owner_id=0){
    // iframe and media responsive wrapper not destructive. Links are reply-to-view protected.
    $html = preg_replace('~<img\b([^>]*)>~i','<img class="sfs-content-img" $1 loading="lazy">',$html);
    $html = preg_replace('~<iframe\b([^>]*)>(.*?)</iframe>~is','<div class="sfs-embed"><iframe $1>$2</iframe></div>',$html);
    if(!can_view_topic_links($topic_id, $topic_owner_id)){
        $html = preg_replace('~<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>~is', locked_link_message(), $html);
    }
    return $html;
}
function maker_link(){ return '<a href="https://projeindir.com.tr" target="_blank" rel="nofollow noopener">Yapımcı Muhammed Salman</a>'; }
function check_maker_integrity(){ return true; }
function role_label($r){ return ['super_admin'=>'Süper Admin','admin'=>'Admin','moderator'=>'Moderatör','editor'=>'Editör','vip'=>'VIP Üye','member'=>'Üye','banned'=>'Yasaklı'][$r] ?? $r; }
function schema_json($arr){ return '<script type="application/ld+json">'.json_encode($arr,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).'</script>'; }


function sfs_mail_enabled(){ return setting('smtp_enabled','1') === '1'; }
function sfs_email_verification_enabled(){ return setting('email_verification_enabled','1') === '1'; }
function sfs_site_email(){ return setting('smtp_from_email', setting('smtp_user','noreply@localhost')); }
function sfs_site_from_name(){ return setting('smtp_from_name', setting('site_title', SFS_NAME)); }
function sfs_smtp_send_raw($to, $subject, $html, $text=''){
    $host=setting('smtp_host',''); $port=(int)setting('smtp_port','587'); $secure=setting('smtp_secure','tls');
    $user=setting('smtp_user',''); $pass=setting('smtp_pass',''); $from=setting('smtp_from_email',$user); $fromName=setting('smtp_from_name',SFS_NAME);
    if(!$host || !$from) return false;
    $remote = ($secure==='ssl'?'ssl://':'').$host.':'.$port;
    $fp = @stream_socket_client($remote, $errno, $errstr, 15, STREAM_CLIENT_CONNECT);
    if(!$fp) return false;
    stream_set_timeout($fp, 15);
    $read=function() use($fp){ $data=''; while($line=fgets($fp,515)){ $data.=$line; if(strlen($line)<4 || $line[3]===' ') break; } return $data; };
    $cmd=function($c) use($fp,$read){ fwrite($fp,$c."\r\n"); return $read(); };
    $read();
    $cmd('EHLO '.($_SERVER['SERVER_NAME'] ?? 'localhost'));
    if($secure==='tls'){
        $cmd('STARTTLS');
        @stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
        $cmd('EHLO '.($_SERVER['SERVER_NAME'] ?? 'localhost'));
    }
    if($user && $pass){
        $cmd('AUTH LOGIN');
        $cmd(base64_encode($user));
        $cmd(base64_encode($pass));
    }
    $boundary='b'.bin2hex(random_bytes(10));
    $subj='=?UTF-8?B?'.base64_encode($subject).'?=';
    $headers=[];
    $headers[]='From: =?UTF-8?B?'.base64_encode($fromName).'?= <'.$from.'>';
    $headers[]='MIME-Version: 1.0';
    $headers[]='Content-Type: multipart/alternative; boundary="'.$boundary.'"';
    $body="--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".($text?:strip_tags($html))."\r\n";
    $body.="--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$html."\r\n--$boundary--\r\n";
    $cmd('MAIL FROM:<'.$from.'>'); $cmd('RCPT TO:<'.$to.'>'); $cmd('DATA');
    fwrite($fp, "Subject: $subj\r\n".implode("\r\n",$headers)."\r\n\r\n".$body."\r\n.\r\n");
    $resp=$read(); $cmd('QUIT'); fclose($fp);
    return strpos($resp,'250')!==false || strpos($resp,'queued')!==false;
}
function sfs_send_mail($to,$subject,$html,$text=''){
    if(sfs_mail_enabled() && sfs_smtp_send_raw($to,$subject,$html,$text)) return true;
    $headers="MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nFrom: ".sfs_site_from_name()." <".sfs_site_email().">\r\n";
    return @mail($to,'=?UTF-8?B?'.base64_encode($subject).'?=',$html,$headers);
}
function sfs_send_verification_mail($userId){
    $q=db()->prepare('SELECT id,username,email,email_verify_token FROM sfs_users WHERE id=? LIMIT 1'); $q->execute([(int)$userId]); $u=$q->fetch(); if(!$u) return false;
    $token=$u['email_verify_token'];
    if(!$token){ $token=bin2hex(random_bytes(32)); db()->prepare('UPDATE sfs_users SET email_verify_token=?, email_verify_expires=DATE_ADD(NOW(), INTERVAL 24 HOUR) WHERE id=?')->execute([$token,$u['id']]); }
    $url=base_url('mail-dogrula.php?token='.urlencode($token));
    $title=setting('site_title',SFS_NAME).' - Mail Doğrulama';
    $html='<div style="font-family:Arial,sans-serif;background:#f4f7fb;padding:24px"><div style="max-width:620px;margin:auto;background:#fff;border:1px solid #dbe8f5;border-radius:14px;padding:22px"><h2 style="color:#173c78">Mail adresini doğrula</h2><p>Merhaba <b>'.e($u['username']).'</b>, üyeliğini aktif etmek için aşağıdaki butona tıkla.</p><p><a href="'.e($url).'" style="display:inline-block;background:#173c78;color:#fff;padding:12px 18px;border-radius:10px;text-decoration:none;font-weight:bold">Üyeliğimi Doğrula</a></p><p style="color:#667085;font-size:13px">Link 24 saat geçerlidir. Buton çalışmazsa bu bağlantıyı tarayıcıya yapıştır: <br>'.e($url).'</p></div></div>';
    return sfs_send_mail($u['email'],$title,$html,strip_tags($html));
}
function sfs_reply_quality_check($html, $topicTitle=''){
    if(setting('reply_quality_enabled','1') !== '1') return [true,''];
    $text=trim(preg_replace('/\s+/u',' ', html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8')));
    $lower=mb_strtolower($text,'UTF-8');
    $min=(int)setting('reply_min_chars','18');
    if(mb_strlen($text,'UTF-8') < $min) return [false,'Cevabın çok kısa. Lütfen konuya katkı sağlayacak daha açıklayıcı bir cevap yaz.'];
    $bad=['asd','asdasd','asdf','qwe','qwerty','test','deneme','123','123456','aaaaaaaa','bbbbbbbb','....','????','!!!!!','sa','slm'];
    foreach($bad as $b){ if($lower===$b || preg_match('~^'.preg_quote($b,'~').'+$~u',$lower)) return [false,'Rastgele veya anlamsız cevap kabul edilmez. Lütfen gerçek ve konuya uygun bir cevap yaz.']; }
    if(preg_match('/(.)\1{5,}/u',$lower)) return [false,'Aynı karakteri sürekli tekrar eden cevaplar kabul edilmez.'];
    preg_match_all('/[\p{L}\p{N}]+/u',$lower,$m); $words=$m[0]??[]; $unique=array_unique($words);
    if(count($unique)<3) return [false,'Cevap daha anlamlı olmalı. En az birkaç farklı kelimeyle konuya katkı sağlayacak şekilde yaz.'];
    $letters=preg_replace('/[^\p{L}]/u','',$lower); if($letters && !preg_match('/[aeıioöuü]/u',$letters) && mb_strlen($letters,'UTF-8')>8) return [false,'Cevap anlamsız görünüyor. Lütfen okunabilir ve mantıklı bir cevap yaz.'];
    return [true,''];
}

?>
