<?php require_once __DIR__.'/app/core.php'; logout_user(); redirect('');
