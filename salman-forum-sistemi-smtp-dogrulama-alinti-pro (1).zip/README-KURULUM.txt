Salman Forum Sistemi - SMTP Mail Doğrulama + Alıntı + Cevap Kalitesi Sürümü

Kurulum:
1) ZIP içindeki dosyaları kuracağınız klasöre direkt atın. Örnek: localhost/index.php veya localhost/v3/index.php
2) Siteyi açın, kurulum ekranı otomatik gelir.
3) MySQL bilgilerini girin.
4) SMTP alanlarını doldurun. Gmail için smtp.gmail.com / 587 / TLS kullanın. Şifre alanına normal Gmail şifresi değil, Gmail uygulama şifresi yazın.
5) Kurulum bitince install klasörünü silin.

Özellikler:
- Üyelikte mail doğrulama
- Doğrulama mailini tekrar gönderme
- Admin panelden SMTP ayarı
- Cevaplarda Alıntıla butonu
- Mantıklı cevap filtresi: asd, qwe, test, tek kelime, tekrar karakter vs. engellenir
- Opsiyonel AI moderasyon ayarları
- Zengin yerel editör
- SEO direkt slug: site.com/konu-basligi
