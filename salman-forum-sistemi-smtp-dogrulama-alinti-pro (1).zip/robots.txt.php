<?php require_once __DIR__.'/app/core.php'; header('Content-Type: text/plain; charset=utf-8'); $host=((!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost'); ?>
User-agent: *
Allow: /
Disallow: /admin/
Disallow: /app/
Disallow: /install/
Sitemap: <?=$host.base_url('sitemap.xml.php')?>
