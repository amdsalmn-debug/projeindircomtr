<?php
require_once __DIR__.'/app/core.php'; require_install();
$token=trim($_GET['token']??''); $title='Mail Doğrulama'; include __DIR__.'/app/header.php';
echo '<section class="panel"><div class="panel-title">Mail Doğrulama</div><div class="panel-body">';
if($token===''){ echo '<div class="notice">Geçersiz doğrulama bağlantısı.</div>'; }
else{
 $q=db()->prepare('SELECT id,email_verified,email_verify_expires FROM sfs_users WHERE email_verify_token=? LIMIT 1'); $q->execute([$token]); $u=$q->fetch();
 if(!$u) echo '<div class="notice">Doğrulama bağlantısı geçersiz veya daha önce kullanılmış.</div>';
 elseif((int)$u['email_verified']===1) echo '<div class="notice">Bu hesap zaten doğrulanmış.</div>';
 elseif(strtotime($u['email_verify_expires']) < time()) echo '<div class="notice">Doğrulama bağlantısının süresi dolmuş. Yeni doğrulama maili iste.</div>';
 else{ db()->prepare('UPDATE sfs_users SET email_verified=1,email_verify_token=NULL,email_verify_expires=NULL WHERE id=?')->execute([$u['id']]); echo '<div class="notice">Mail adresin başarıyla doğrulandı. Artık giriş yapabilirsin.</div><p><a class="btn" href="'.base_url('giris.php').'">Giriş Yap</a></p>'; }
}
echo '</div></section>'; include __DIR__.'/app/footer.php';
