<?php
require_once __DIR__.'/app/core.php';
require_install();
$slug=$_GET['slug']??'';
$q=db()->prepare("SELECT t.*,u.username,u.avatar,u.role,u.created_at user_created_at,f.title forum_title,
(SELECT COUNT(*) FROM sfs_topics tt WHERE tt.user_id=u.id AND tt.status='published') topic_count,
(SELECT COUNT(*) FROM sfs_replies rr WHERE rr.user_id=u.id AND rr.status='published') reply_count
FROM sfs_topics t
JOIN sfs_users u ON u.id=t.user_id
JOIN sfs_forums f ON f.id=t.forum_id
WHERE t.slug=? LIMIT 1");
$q->execute([$slug]);
$t=$q->fetch();
if(!$t){
    http_response_code(404);
    $page_title='Konu bulunamadı';
    include __DIR__.'/app/header.php';
    echo '<div class="panel"><div class="panel-body">Konu bulunamadı.</div></div>';
    include __DIR__.'/app/footer.php';
    exit;
}
db()->prepare('UPDATE sfs_topics SET views=views+1 WHERE id=?')->execute([$t['id']]);
$page_title=$t['title'].' - '.setting('site_title',SFS_NAME);
$page_desc=mb_substr(strip_tags($t['content']),0,160);
include __DIR__.'/app/header.php';

function sfs_role_class($role){
    $role = preg_replace('~[^a-z0-9_\-]~i','', (string)$role);
    return $role ?: 'member';
}
function sfs_date_short($date){
    if(!$date) return '-';
    $ts = strtotime($date);
    return $ts ? date('d.m.Y', $ts) : e($date);
}
function sfs_user_card($row, $label='Konu Sahibi'){
    $avatar = $row['avatar'] ?: asset('assets/avatar.svg');
    $role = $row['role'] ?? 'member';
    $topics = (int)($row['topic_count'] ?? 0);
    $replies = (int)($row['reply_count'] ?? 0);
    ob_start(); ?>
    <aside class="sfs-author-card">
        <div class="author-glow"></div>
        <div class="author-label"><?=e($label)?></div>
        <div class="author-avatar-frame">
            <img class="author-avatar" src="<?=e($avatar)?>" alt="<?=e($row['username'] ?? 'Üye')?>">
        </div>
        <div class="author-name"><?=e($row['username'] ?? 'Üye')?></div>
        <span class="author-role role-<?=e(sfs_role_class($role))?>"><?=e(role_label($role))?></span>
        <div class="author-stats">
            <div><b><?=number_format($topics)?></b><span>Konu</span></div>
            <div><b><?=number_format($replies)?></b><span>Cevap</span></div>
        </div>
        <div class="author-meta">
            <span>Katılım</span>
            <strong><?=e(sfs_date_short($row['user_created_at'] ?? ''))?></strong>
        </div>
    </aside>
    <?php return ob_get_clean();
}
?>

<section class="topic-hero panel">
    <div class="topic-hero-top">
        <div>
            <div class="topic-breadcrumb">Forum: <strong><?=e($t['forum_title'])?></strong></div>
            <h1><?=e($t['title'])?></h1>
            <div class="topic-meta-line">
                <span>👁 <?=e($t['views']+1)?> okunma</span>
                <span>💬 <?=e($t['replies'])?> cevap</span>
                <span>📅 <?=e(sfs_date_short($t['created_at']))?></span>
            </div>
        </div>
        <a class="btn topic-reply-jump" href="#cevap-yaz">Cevap Yaz</a>
    </div>
    <?php if($t['cover']):?>
        <div class="topic-cover-wrap"><img class="topic-cover" src="<?=e($t['cover'])?>" alt="<?=e($t['title'])?>"></div>
    <?php endif;?>
</section>

<div class="sfs-post-card topic-main-post">
    <?=sfs_user_card($t, 'Konu Sahibi')?>
    <article class="sfs-post-content">
        <div class="post-content-head">
            <div>
                <strong><?=e($t['title'])?></strong>
                <span><?=e($t['created_at'])?></span>
            </div>
            <div class="actions"><button type="button" class="quote-btn" data-quote-insert data-quote-user="<?=e($t['username'])?>" data-quote-text="<?=e(mb_substr(strip_tags($t['content']),0,600))?>">Alıntıla</button><span class="post-number">#1</span></div>
        </div>
        <div class="post-body content topic-content"><?=secure_content($t['content'], $t['id'], $t['user_id'])?></div>
        <div class="post-signature">Salman Forum Sistemi üzerinden gönderildi.</div>
    </article>
</div>

<section class="panel replies-panel">
    <div class="panel-title"><span>Cevaplar</span><span><?=e($t['replies'])?> cevap</span></div>
    <div class="panel-body">
<?php
$r=db()->prepare("SELECT r.*,u.username,u.avatar,u.role,u.created_at user_created_at,
(SELECT COUNT(*) FROM sfs_topics tt WHERE tt.user_id=u.id AND tt.status='published') topic_count,
(SELECT COUNT(*) FROM sfs_replies rr WHERE rr.user_id=u.id AND rr.status='published') reply_count
FROM sfs_replies r
JOIN sfs_users u ON u.id=r.user_id
WHERE r.topic_id=? AND r.status='published'
ORDER BY r.id ASC");
$r->execute([$t['id']]);
$replyNo=2;
foreach($r->fetchAll() as $rep): ?>
        <div class="sfs-post-card reply-post">
            <?=sfs_user_card($rep, 'Cevap')?>
            <article class="sfs-post-content">
                <div class="post-content-head"><div><strong><?=e($rep['username'])?> yanıtladı</strong><span><?=e($rep['created_at'])?></span></div><div class="actions"><button type="button" class="quote-btn" data-quote-insert data-quote-user="<?=e($rep['username'])?>" data-quote-text="<?=e(mb_substr(strip_tags($rep['content']),0,600))?>">Alıntıla</button><span class="post-number">#<?=$replyNo++?></span></div></div>
                <div class="post-body content topic-content"><?=secure_content($rep['content'], $t['id'], $t['user_id'])?></div>
            </article>
        </div>
<?php endforeach; ?>
<?php if(!current_user()):?>
        <div class="notice premium-notice">Bu konudaki linkleri görebilmek için üye girişi yapıp konuya cevap yazmanız gerekiyor. Cevap sonrası linkler otomatik açılır.</div>
<?php else: ?>
        <div id="cevap-yaz"><?php include __DIR__.'/app/reply_form.php'; ?></div>
<?php endif; ?>
    </div>
</section>
<?php include __DIR__.'/app/footer.php'; ?>
