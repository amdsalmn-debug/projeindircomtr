<?php
require_once __DIR__.'/app/core.php'; require_install(); if(current_user()) redirect('panel.php');
$err=''; $msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_check();
    $email=trim($_POST['email']??''); $user=trim($_POST['username']??''); $pass=$_POST['password']??'';
    if(!$email || !filter_var($email,FILTER_VALIDATE_EMAIL) || !$user || strlen($pass)<4) $err='Bilgileri kontrol et. Geçerli e-posta ve en az 4 karakter şifre gerekli.';
    else try{
        $verified = sfs_email_verification_enabled() ? 0 : 1;
        $token = $verified ? null : bin2hex(random_bytes(32));
        $expires = $verified ? null : date('Y-m-d H:i:s', time()+86400);
        $st=db()->prepare('INSERT INTO sfs_users(username,email,password,role,ip,email_verified,email_verify_token,email_verify_expires) VALUES(?,?,?,?,?,?,?,?)');
        $st->execute([$user,$email,password_hash($pass,PASSWORD_DEFAULT),'member',$_SERVER['REMOTE_ADDR']??'',$verified,$token,$expires]);
        $uid=(int)db()->lastInsertId();
        if(!$verified){
            sfs_send_verification_mail($uid);
            $msg='Üyeliğin oluşturuldu. Giriş yapabilmek için e-posta adresine gönderilen doğrulama bağlantısına tıkla.';
        } else { login_user($uid); redirect('panel.php'); }
    }catch(Throwable $e){$err='Bu e-posta kullanılıyor olabilir veya kayıt yapılamadı.';}
}
$page_title='Üye Ol'; include __DIR__.'/app/header.php'; ?>
<section class="panel"><div class="panel-title">Üye Ol</div><div class="panel-body form"><?php if($err):?><div class="notice"><?=e($err)?></div><?php endif;?><?php if($msg):?><div class="notice"><?=e($msg)?></div><p><a class="btn" href="<?=base_url('dogrulama-tekrar.php')?>">Doğrulama maili tekrar gönder</a></p><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=csrf()?>"><label>Kullanıcı adı</label><input class="input" name="username" required><label>E-posta</label><input class="input" name="email" type="email" required><label>Şifre</label><input class="input" type="password" name="password" required><br><button class="btn">Kayıt Ol</button></form></div></section><?php include __DIR__.'/app/footer.php'; ?>
