CREATE TABLE IF NOT EXISTS sfs_settings (name varchar(120) PRIMARY KEY, value text) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS sfs_users (
  id int auto_increment PRIMARY KEY,
  username varchar(80) not null,
  email varchar(190) not null unique,
  password varchar(255) not null,
  role varchar(30) not null default 'member',
  avatar varchar(255) default '',
  banned tinyint default 0,
  email_verified tinyint(1) not null default 0,
  email_verify_token varchar(128) null,
  email_verify_expires datetime null,
  ip varchar(60) default '',
  created_at datetime default current_timestamp,
  INDEX(role), INDEX(email_verified), INDEX(email_verify_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS sfs_categories (id int auto_increment PRIMARY KEY, title varchar(160) not null, slug varchar(180) not null unique, description text, sort_order int default 0, active tinyint default 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS sfs_forums (id int auto_increment PRIMARY KEY, category_id int not null, title varchar(160) not null, slug varchar(180) not null unique, description text, sort_order int default 0, active tinyint default 1, INDEX(category_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS sfs_topics (id int auto_increment PRIMARY KEY, forum_id int not null, user_id int not null, title varchar(220) not null, slug varchar(240) not null unique, content longtext not null, cover varchar(255) default '', status varchar(20) default 'published', is_sticky tinyint default 0, is_locked tinyint default 0, views int default 0, replies int default 0, last_reply_at datetime null, created_at datetime default current_timestamp, updated_at datetime default current_timestamp on update current_timestamp, FULLTEXT KEY ft_topic(title,content), INDEX(slug), INDEX(forum_id), INDEX(user_id), INDEX(created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS sfs_replies (id int auto_increment PRIMARY KEY, topic_id int not null, user_id int not null, content longtext not null, status varchar(20) default 'published', created_at datetime default current_timestamp, INDEX(topic_id), INDEX(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS sfs_online (session_id varchar(128) PRIMARY KEY, user_id int null, username varchar(100), ip varchar(60), user_agent varchar(255), is_bot tinyint default 0, bot_name varchar(80), last_seen datetime, INDEX(last_seen), INDEX(is_bot)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS sfs_bans (id int auto_increment PRIMARY KEY, type varchar(20), value varchar(190), reason text, created_at datetime default current_timestamp) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
