<?php require_once __DIR__.'/app/core.php'; require_install(); $page_title=setting('site_title',SFS_NAME); include __DIR__.'/app/header.php'; ?>
<section class="panel"><div class="panel-title"><span>Son Güncellenen Konular</span><a class="btn-gold" href="<?=base_url('yeni-konu.php')?>">Yeni Konu Aç</a></div><div>
<?php $topics=db()->query("SELECT t.*,u.username,u.avatar,f.title forum_title FROM sfs_topics t JOIN sfs_users u ON u.id=t.user_id JOIN sfs_forums f ON f.id=t.forum_id WHERE t.status='published' ORDER BY t.is_sticky DESC, COALESCE(t.last_reply_at,t.created_at) DESC LIMIT 12")->fetchAll(); foreach($topics as $t): ?>
<div class="topic-row"><img class="topic-thumb" src="<?=e($t['cover'] ?: asset('assets/img-topic.svg'))?>" onerror="this.style.display='none'"><div><h3><a href="<?=base_url($t['slug'])?>"><?=e($t['title'])?></a></h3><div class="muted"><?=e($t['forum_title'])?> • <?=e($t['username'])?> • <?=e($t['created_at'])?></div></div><div class="stat"><b><?=e($t['views'])?></b>Okunma</div><div class="last muted">Cevap: <?=e($t['replies'])?></div></div>
<?php endforeach; ?>
</div></section>
<?php $cats=db()->query("SELECT * FROM sfs_categories WHERE active=1 ORDER BY sort_order,id")->fetchAll(); foreach($cats as $c): ?>
<section class="panel"><div class="panel-title"><?=e($c['title'])?></div>
<?php $q=db()->prepare("SELECT f.*, (SELECT COUNT(*) FROM sfs_topics t WHERE t.forum_id=f.id) topic_count FROM sfs_forums f WHERE f.category_id=? AND f.active=1 ORDER BY f.sort_order,f.id"); $q->execute([$c['id']]); foreach($q->fetchAll() as $f): ?>
<div class="forum-row"><div class="iconbox">💬</div><div><h3><a href="<?=base_url('forum.php?slug='.$f['slug'])?>"><?=e($f['title'])?></a></h3><div class="muted"><?=e($f['description'])?></div></div><div class="stat"><b><?=e($f['topic_count'])?></b>Konu</div><div class="last muted">Forum aktif</div></div>
<?php endforeach; ?></section><?php endforeach; ?>
<?php include __DIR__.'/app/footer.php'; ?>
