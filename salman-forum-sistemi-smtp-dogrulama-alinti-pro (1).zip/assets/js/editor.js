function sfsExec(cmd,val=null){document.execCommand(cmd,false,val);}
function sfsCleanUrl(u){return (u||'').trim().replaceAll('"','&quot;');}
function sfsPrompt(cmd,msg){let v=prompt(msg||'Değer girin'); if(!v)return; if(cmd==='createLink') sfsExec(cmd,v); if(cmd==='image') sfsExec('insertHTML','<img class="sfs-content-img" src="'+sfsCleanUrl(v)+'" alt="">'); if(cmd==='video') insertEmbed(v);}
function insertEmbed(url){url=(url||'').trim(); let html='';
 if(url.includes('youtube.com')||url.includes('youtu.be')){let id=(url.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([\w-]+)/)||[])[1]; if(id) html='<div class="sfs-embed"><iframe src="https://www.youtube.com/embed/'+id+'" allowfullscreen loading="lazy"></iframe></div>';}
 else if(url.includes('vimeo.com')){let id=(url.match(/vimeo\.com\/(\d+)/)||[])[1]; if(id) html='<div class="sfs-embed"><iframe src="https://player.vimeo.com/video/'+id+'" allowfullscreen loading="lazy"></iframe></div>';}
 else if(url.includes('dailymotion.com')||url.includes('dai.ly')){html='<p><a href="'+sfsCleanUrl(url)+'" target="_blank" rel="nofollow noopener">Dailymotion video bağlantısı</a></p>';}
 else if(url.includes('tiktok.com')){html='<div class="sfs-social-embed"><b>TikTok İçeriği</b><br><a href="'+sfsCleanUrl(url)+'" target="_blank" rel="nofollow noopener">'+url+'</a></div>';}
 else if(url.includes('instagram.com')){html='<div class="sfs-social-embed"><b>Instagram İçeriği</b><br><a href="'+sfsCleanUrl(url)+'" target="_blank" rel="nofollow noopener">'+url+'</a></div>';}
 else if(url.includes('x.com')||url.includes('twitter.com')){html='<div class="sfs-social-embed"><b>X / Twitter İçeriği</b><br><a href="'+sfsCleanUrl(url)+'" target="_blank" rel="nofollow noopener">'+url+'</a></div>';}
 else if(url.includes('facebook.com')){html='<div class="sfs-social-embed"><b>Facebook İçeriği</b><br><a href="'+sfsCleanUrl(url)+'" target="_blank" rel="nofollow noopener">'+url+'</a></div>';}
 else {html='<p><a href="'+sfsCleanUrl(url)+'" target="_blank" rel="nofollow noopener">'+url+'</a></p>';}
 document.execCommand('insertHTML',false,html||'<p><a href="'+sfsCleanUrl(url)+'">'+url+'</a></p>');}
function sfsTable(){document.execCommand('insertHTML',false,'<table class="sfs-table"><tr><th>Başlık</th><th>Başlık</th></tr><tr><td>İçerik</td><td>İçerik</td></tr></table><p></p>');}
function sfsEmoji(){document.execCommand('insertText',false,' 😊 ');}
function sfsQuote(){document.execCommand('insertHTML',false,'<blockquote><b>Alıntı:</b><br>Buraya alıntı metni yazabilirsin.</blockquote><p></p>');}
function sfsCode(){document.execCommand('insertHTML',false,'<pre><code>// Kodunu buraya yaz</code></pre><p></p>');}
function initSfsEditor(root){const area=root.querySelector('.editor-area'), html=root.querySelector('.editor-html'), hidden=document.querySelector(root.dataset.target); if(!area||!hidden)return;
 root.querySelectorAll('[data-cmd]').forEach(b=>b.onclick=()=>{area.focus();sfsExec(b.dataset.cmd,b.dataset.val||null);});
 root.querySelectorAll('[data-format]').forEach(s=>s.onchange=()=>{area.focus();sfsExec('formatBlock',s.value);});
 let link=root.querySelector('[data-link]'); if(link) link.onclick=()=>{area.focus();sfsPrompt('createLink','Link adresi');};
 let image=root.querySelector('[data-image]'); if(image) image.onclick=()=>{area.focus();sfsPrompt('image','Görsel URL');};
 let video=root.querySelector('[data-video]'); if(video) video.onclick=()=>{area.focus();sfsPrompt('video','YouTube / TikTok / X / Instagram / Facebook bağlantısı');};
 let table=root.querySelector('[data-table]'); if(table) table.onclick=()=>{area.focus();sfsTable();};
 let emoji=root.querySelector('[data-emoji]'); if(emoji) emoji.onclick=()=>{area.focus();sfsEmoji();}; let code=root.querySelector('[data-code]'); if(code) code.onclick=()=>{area.focus();sfsCode();}; let hr=root.querySelector('[data-hr]'); if(hr) hr.onclick=()=>{area.focus();document.execCommand('insertHTML',false,'<hr><p></p>')}; let clear=root.querySelector('[data-clear]'); if(clear) clear.onclick=()=>{if(confirm('Biçim temizlensin mi?')) document.execCommand('removeFormat',false,null);};
 let quote=root.querySelector('[data-quote]'); if(quote) quote.onclick=()=>{area.focus();sfsQuote();};
 let htmlbtn=root.querySelector('[data-html]'); if(htmlbtn) htmlbtn.onclick=()=>{if(html.style.display==='block'){area.innerHTML=html.value; html.style.display='none';area.style.display='block'}else{html.value=area.innerHTML; html.style.display='block';area.style.display='none'}}; let visual=root.querySelector('[data-visual-tab]'); if(visual) visual.onclick=()=>{if(html.style.display==='block'){area.innerHTML=html.value; html.style.display='none';area.style.display='block'}};
 let full=root.querySelector('[data-full]'); if(full) full.onclick=()=>root.classList.toggle('fullscreen');
 root.querySelectorAll('[type=color]').forEach(i=>i.onchange=()=>{area.focus();sfsExec(i.dataset.colorcmd,i.value);});
 ['paste','drop'].forEach(evt=>area.addEventListener(evt,async ev=>{let items=evt==='paste'?ev.clipboardData?.items:ev.dataTransfer?.items; if(!items)return; for(const it of items){const file=it.kind==='file'?it.getAsFile():null;if(file&&file.type&&file.type.startsWith('image/')){ev.preventDefault(); await uploadImage(file);}}}));
 async function uploadImage(file){const fd=new FormData();fd.append('image',file);let base=(window.SFS_BASE||'').replace(/\/$/,'');let r=await fetch(base+'/ajax_upload.php',{method:'POST',body:fd,credentials:'same-origin'});let j=await r.json().catch(()=>({error:'Yükleme cevabı okunamadı'})); if(j.url) document.execCommand('insertHTML',false,'<img class="sfs-content-img" src="'+j.url+'" alt="">'); else alert(j.error||'Yükleme olmadı');}
 const form=root.closest('form'); if(form) form.addEventListener('submit',()=>{hidden.value=(html.style.display==='block')?html.value:area.innerHTML;});}
document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.editor').forEach(initSfsEditor)});


document.addEventListener('click', function(e){
  const btn=e.target.closest('[data-quote-insert]'); if(!btn) return;
  const user=btn.dataset.quoteUser||'Üye'; const text=btn.dataset.quoteText||'';
  const form=document.querySelector('#cevap-formu'); if(!form) return;
  const ed=form.querySelector('.editor-area'); if(!ed) return;
  const safe=text.replace(/</g,'&lt;').replace(/>/g,'&gt;');
  ed.focus(); document.execCommand('insertHTML',false,'<blockquote><b>'+user+' yazdı:</b><br>'+safe+'</blockquote><p></p>');
  document.querySelector('#cevap-yaz')?.scrollIntoView({behavior:'smooth'});
});
