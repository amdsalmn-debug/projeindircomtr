function sfsSyncEditors(){
  document.querySelectorAll('.editor').forEach(function(root){
    const area=root.querySelector('.editor-area');
    const html=root.querySelector('.editor-html');
    const hidden=document.querySelector(root.dataset.target);
    if(hidden){ hidden.value = (html && html.style.display==='block') ? html.value : (area ? area.innerHTML : hidden.value); }
  });
}
document.addEventListener('submit',function(e){
 const f=e.target; sfsSyncEditors();
 if(!f.classList.contains('topic-submit-form')) return;
 if(f.dataset.ready==='1') return;
 e.preventDefault();
 let n=10; const box=f.querySelector('.countdown'); const btn=f.querySelector('[type=submit]');
 const isReply = (f.getAttribute('action')||'').includes('cevap-kaydet'); const text = isReply ? 'Cevabınız' : 'Yeni konunuz';
 if(box){box.style.display='block';box.textContent=text+' '+n+' saniye içinde kaydedilecek. Lütfen bekleyin...';}
 if(btn) btn.disabled=true;
 const t=setInterval(()=>{n--; if(box) box.textContent=text+' '+n+' saniye içinde kaydedilecek. Lütfen bekleyin...'; if(n<=0){clearInterval(t); sfsSyncEditors(); f.dataset.ready='1'; HTMLFormElement.prototype.submit.call(f);}},1000);
});
